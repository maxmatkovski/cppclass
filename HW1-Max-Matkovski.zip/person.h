#ifndef PERSON_H
#define PERSON_H
#include <string>
using namespace std;

class Person {
public:

	int player_score;
	string player_name;

};


#endif // !PERSON_H

