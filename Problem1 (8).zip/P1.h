#pragma once
/*
 P1.h

 INSTRUCTIONS:
 Do not modify this file. You will not be submitting this, so your changes will be lost

 Program the combinations function as specified in the problem statement (in the P1.cpp file).
 */

#ifndef P1_h
#define P1_h

#include <vector>

std::vector<std::vector<int>> combinations(int n, int k);


#endif /* P1_h */
