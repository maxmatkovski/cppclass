#include "P1.h"
#include <algorithm>

using namespace std;
vector<vector<int>> combinations(int n, int k) {

	vector<bool> v(n);
	fill(v.begin(), v.begin() + k, true);
	vector<vector<int>> combs;

    do {
        vector<int> comb;
        for (int i = 0; i < n; ++i) {
            if (v[i]) {
                comb.push_back(i + 1);
            }
        }
        combs.push_back(comb);
    } while (prev_permutation(v.begin(), v.end()));
    return combs;
}